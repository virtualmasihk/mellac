# MellAC - Minecraft Anti-Cheat Plugin

Плагин для мониторинга и обнаружения читов на Minecraft серверах (Spigot 1.16.5+).

## Возможности

- 🔍 Автоматическое обнаружение читов:
  - Speed (повышенная скорость)
  - Fly (полёт)
  - Teleport (телепортация)
  - Phase (прохождение сквозь блоки)
  
- 📊 Отправка отчётов на веб-панель
- ⚙️ Гибкая настройка через config.yml
- 🎯 Система очередей для минимальной нагрузки на сервер
- 📝 Детальное логирование движений игроков
- 🛡️ Система исключений (bypass)

## Установка

1. Скачайте плагин MellAC.jar
2. Поместите в папку `plugins/` вашего сервера
3. Запустите сервер (будет создан config.yml)
4. Получите API ключ на панели управления: http://f1.veltox.xyz:20012/dashboard/servers
5. Откройте `plugins/MellAC/config.yml` и укажите:
   - `api.key` - ваш API ключ
   - `api.url` - http://f1.veltox.xyz:20012
6. Перезапустите сервер или выполните `/mellac reload`

## Команды

- `/mellac reload` - Перезагрузить конфигурацию
- `/mellac status` - Показать статус плагина
- `/mellac check <игрок>` - Проверить конкретного игрока
- `/mellac debug` - Включить/выключить режим отладки

## Права

- `mellac.admin` - Доступ к командам (по умолчанию: OP)
- `mellac.bypass` - Игнорировать проверки (по умолчанию: false)

## Настройка

### Основные параметры

```yaml
api:
  key: "YOUR_API_KEY_HERE"  # Ваш API ключ
  url: "http://f1.veltox.xyz:20012"  # URL панели
  timeout: 10  # Таймаут запросов

monitoring:
  enabled: true  # Включить мониторинг
  check-interval: 30  # Интервал проверки (секунды)
  max-concurrent-checks: 3  # Макс. одновременных проверок
```

### Настройка обнаружения

Каждый тип проверки можно включить/выключить и настроить порог срабатывания:

```yaml
detection:
  speed:
    enabled: true
    max-speed: 12.0  # Максимальная скорость (блоков/сек)
    threshold: 3  # Количество нарушений для отчёта
```

### Исключения

```yaml
bypass:
  players:
    - "AdminName"  # Игроки для игнорирования
  ignore-creative: true  # Игнорировать креатив
  ignore-effects: true  # Игнорировать эффекты зелий
```

## Сборка из исходников

Требования:
- Java 8+
- Maven 3.6+

```bash
cd MellAC
mvn clean package
```

Готовый JAR будет в `target/MellAC-1.0.0.jar`

## Поддержка

- Документация: http://f1.veltox.xyz:20012/dashboard/wiki
- Поддержка: http://f1.veltox.xyz:20012/dashboard/support

## Лицензия

© 2024 MellAC Team. Все права защищены.
