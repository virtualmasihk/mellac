# Инструкция по сборке MellAC

## Требования

- Java Development Kit (JDK) 8 или выше
- Apache Maven 3.6 или выше

## Установка Maven (Windows)

1. Скачайте Maven: https://maven.apache.org/download.cgi
2. Распакуйте в `C:\Program Files\Apache\maven`
3. Добавьте в PATH: `C:\Program Files\Apache\maven\bin`
4. Проверьте: `mvn -version`

## Сборка плагина

1. Откройте командную строку в папке MellAC:
```bash
cd MellAC
```

2. Выполните сборку:
```bash
mvn clean package
```

3. Готовый плагин будет в:
```
target/MellAC-1.0.0.jar
```

## Быстрая сборка (без тестов)

```bash
mvn clean package -DskipTests
```

## Установка на сервер

1. Скопируйте `target/MellAC-1.0.0.jar` в папку `plugins/` вашего Minecraft сервера
2. Запустите сервер
3. Настройте `plugins/MellAC/config.yml`
4. Перезапустите сервер

## Возможные проблемы

### Maven не найден
- Убедитесь что Maven установлен и добавлен в PATH
- Перезапустите командную строку после установки

### Ошибка компиляции
- Проверьте версию Java: `java -version`
- Должна быть Java 8 или выше

### Не скачиваются зависимости
- Проверьте интернет-соединение
- Maven автоматически скачает Spigot API при первой сборке

## Разработка

Для разработки рекомендуется использовать:
- IntelliJ IDEA (с плагином Maven)
- Eclipse (с плагином M2Eclipse)

Импортируйте проект как Maven проект.
