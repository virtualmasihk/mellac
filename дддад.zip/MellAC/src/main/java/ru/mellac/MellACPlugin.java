package ru.mellac;

import org.bukkit.plugin.java.JavaPlugin;
import ru.mellac.api.ApiClient;
import ru.mellac.checker.CheatChecker;
import ru.mellac.command.MellACCommand;
import ru.mellac.listener.PlayerListener;
import ru.mellac.manager.CheckManager;

public class MellACPlugin extends JavaPlugin {
    
    private static MellACPlugin instance;
    private ApiClient apiClient;
    private CheckManager checkManager;
    private CheatChecker cheatChecker;
    
    @Override
    public void onEnable() {
        instance = this;
        
        // Сохранить конфиг по умолчанию
        saveDefaultConfig();
        
        // Проверить API ключ
        String apiKey = getConfig().getString("api.key", "");
        if (apiKey.isEmpty() || apiKey.equals("YOUR_API_KEY_HERE")) {
            getLogger().warning("===========================================");
            getLogger().warning("API ключ не настроен!");
            getLogger().warning("Получите ключ на панели управления и");
            getLogger().warning("укажите его в config.yml");
            getLogger().warning("===========================================");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        
        // Инициализация компонентов
        this.apiClient = new ApiClient(this);
        this.cheatChecker = new CheatChecker(this);
        this.checkManager = new CheckManager(this);
        
        // Регистрация команд
        getCommand("mellac").setExecutor(new MellACCommand(this));
        
        // Регистрация слушателей
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getServer().getPluginManager().registerEvents(new ru.mellac.listener.CombatListener(this), this);
        
        // Запуск мониторинга
        if (getConfig().getBoolean("monitoring.enabled", true)) {
            checkManager.start();
        }
        
        getLogger().info("MellAC успешно запущен!");
        getLogger().info("Мониторинг: " + (getConfig().getBoolean("monitoring.enabled") ? "Включен" : "Выключен"));
    }
    
    @Override
    public void onDisable() {
        if (checkManager != null) {
            checkManager.stop();
        }
        getLogger().info("MellAC остановлен!");
    }
    
    public static MellACPlugin getInstance() {
        return instance;
    }
    
    public ApiClient getApiClient() {
        return apiClient;
    }
    
    public CheckManager getCheckManager() {
        return checkManager;
    }
    
    public CheatChecker getCheatChecker() {
        return cheatChecker;
    }
}
