package ru.mellac.api;

import org.bukkit.Bukkit;
import ru.mellac.MellACPlugin;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class ApiClient {
    
    private final MellACPlugin plugin;
    private final String apiUrl;
    private final String apiKey;
    private final int timeout;
    
    public ApiClient(MellACPlugin plugin) {
        this.plugin = plugin;
        this.apiUrl = plugin.getConfig().getString("api.url", "https://your-domain.com");
        this.apiKey = plugin.getConfig().getString("api.key", "");
        this.timeout = plugin.getConfig().getInt("api.timeout", 10) * 1000;
    }
    
    public void sendCheatReport(String playerName, String playerIp, String cheatType, 
                                String cheatReason, String severity) {
        // Асинхронная отправка
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                String endpoint = apiUrl + "/api/cheat-reports";
                URL url = new URL(endpoint);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");
                conn.setDoOutput(true);
                conn.setConnectTimeout(timeout);
                conn.setReadTimeout(timeout);
                
                // Формирование JSON
                StringBuilder json = new StringBuilder();
                json.append("{");
                json.append("\"api_key\":\"").append(escapeJson(apiKey)).append("\",");
                json.append("\"player_name\":\"").append(escapeJson(playerName)).append("\",");
                
                if (playerIp != null && plugin.getConfig().getBoolean("reports.send-ip", true)) {
                    json.append("\"player_ip\":\"").append(escapeJson(playerIp)).append("\",");
                }
                
                json.append("\"cheat_type\":\"").append(escapeJson(cheatType)).append("\",");
                json.append("\"cheat_reason\":\"").append(escapeJson(cheatReason)).append("\",");
                json.append("\"severity\":\"").append(escapeJson(severity)).append("\"");
                json.append("}");
                
                // Отправка
                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = json.toString().getBytes(StandardCharsets.UTF_8);
                    os.write(input, 0, input.length);
                }
                
                // Чтение ответа
                int responseCode = conn.getResponseCode();
                
                if (responseCode == 200) {
                    if (plugin.getConfig().getBoolean("debug.enabled", false)) {
                        plugin.getLogger().info("Отчёт отправлен: " + playerName + " - " + cheatType);
                    }
                } else {
                    BufferedReader br = new BufferedReader(
                        new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8)
                    );
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) {
                        response.append(line);
                    }
                    plugin.getLogger().warning("Ошибка отправки отчёта (код " + responseCode + "): " + response);
                }
                
                conn.disconnect();
                
            } catch (Exception e) {
                plugin.getLogger().warning("Не удалось отправить отчёт: " + e.getMessage());
                if (plugin.getConfig().getBoolean("debug.enabled", false)) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    private String escapeJson(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }
}
