package ru.mellac.manager;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import ru.mellac.MellACPlugin;
import ru.mellac.data.PlayerData;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class CheckManager {
    
    private final MellACPlugin plugin;
    private final Map<UUID, PlayerData> playerDataMap;
    private final Queue<UUID> checkQueue;
    private BukkitTask checkTask;
    private final int checkInterval;
    private final int maxConcurrentChecks;
    
    public CheckManager(MellACPlugin plugin) {
        this.plugin = plugin;
        this.playerDataMap = new ConcurrentHashMap<>();
        this.checkQueue = new LinkedList<>();
        this.checkInterval = plugin.getConfig().getInt("monitoring.check-interval", 30) * 20; // в тиках
        this.maxConcurrentChecks = plugin.getConfig().getInt("monitoring.max-concurrent-checks", 3);
    }
    
    public void start() {
        // Задача проверки игроков
        checkTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            // Добавить всех онлайн игроков в очередь
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (!checkQueue.contains(player.getUniqueId()) && !shouldBypass(player)) {
                    checkQueue.offer(player.getUniqueId());
                }
            }
            
            // Проверить несколько игроков из очереди
            int checked = 0;
            while (checked < maxConcurrentChecks && !checkQueue.isEmpty()) {
                UUID uuid = checkQueue.poll();
                Player player = Bukkit.getPlayer(uuid);
                
                if (player != null && player.isOnline()) {
                    plugin.getCheatChecker().checkPlayer(player);
                    checked++;
                }
            }
            
        }, 20L, checkInterval);
        
        plugin.getLogger().info("Менеджер проверок запущен (интервал: " + (checkInterval / 20) + "с)");
    }
    
    public void stop() {
        if (checkTask != null) {
            checkTask.cancel();
        }
        playerDataMap.clear();
        checkQueue.clear();
    }
    
    public PlayerData getPlayerData(UUID uuid) {
        return playerDataMap.computeIfAbsent(uuid, k -> new PlayerData(uuid));
    }
    
    public void removePlayerData(UUID uuid) {
        playerDataMap.remove(uuid);
        checkQueue.remove(uuid);
    }
    
    private boolean shouldBypass(Player player) {
        // Проверка прав
        if (player.hasPermission("mellac.bypass")) {
            return true;
        }
        
        // Проверка списка исключений
        List<String> bypassList = plugin.getConfig().getStringList("bypass.players");
        if (bypassList.contains(player.getName())) {
            return true;
        }
        
        // Игнорировать креатив
        if (plugin.getConfig().getBoolean("bypass.ignore-creative", true)) {
            if (player.getGameMode() == org.bukkit.GameMode.CREATIVE || 
                player.getGameMode() == org.bukkit.GameMode.SPECTATOR) {
                return true;
            }
        }
        
        return false;
    }
    
    public int getQueueSize() {
        return checkQueue.size();
    }
    
    public int getTrackedPlayers() {
        return playerDataMap.size();
    }
}
