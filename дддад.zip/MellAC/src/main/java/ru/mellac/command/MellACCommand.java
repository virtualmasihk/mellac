package ru.mellac.command;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import ru.mellac.MellACPlugin;

public class MellACCommand implements CommandExecutor {
    
    private final MellACPlugin plugin;
    
    public MellACCommand(MellACPlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("mellac.admin")) {
            sender.sendMessage(ChatColor.RED + "У вас нет прав для использования этой команды!");
            return true;
        }
        
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }
        
        switch (args[0].toLowerCase()) {
            case "reload":
                plugin.reloadConfig();
                sender.sendMessage(ChatColor.GREEN + "Конфигурация перезагружена!");
                break;
                
            case "status":
                sendStatus(sender);
                break;
                
            case "check":
                if (args.length < 2) {
                    sender.sendMessage(ChatColor.RED + "Использование: /mellac check <игрок>");
                    return true;
                }
                
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage(ChatColor.RED + "Игрок не найден!");
                    return true;
                }
                
                plugin.getCheatChecker().checkPlayer(target);
                sender.sendMessage(ChatColor.GREEN + "Проверка игрока " + target.getName() + " выполнена!");
                break;
                
            case "debug":
                boolean currentDebug = plugin.getConfig().getBoolean("debug.enabled", false);
                plugin.getConfig().set("debug.enabled", !currentDebug);
                sender.sendMessage(ChatColor.GREEN + "Режим отладки: " + 
                    (currentDebug ? ChatColor.RED + "Выключен" : ChatColor.GREEN + "Включен"));
                break;
                
            default:
                sendHelp(sender);
                break;
        }
        
        return true;
    }
    
    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "=== MellAC Команды ===");
        sender.sendMessage(ChatColor.YELLOW + "/mellac reload" + ChatColor.GRAY + " - Перезагрузить конфигурацию");
        sender.sendMessage(ChatColor.YELLOW + "/mellac status" + ChatColor.GRAY + " - Показать статус плагина");
        sender.sendMessage(ChatColor.YELLOW + "/mellac check <игрок>" + ChatColor.GRAY + " - Проверить игрока");
        sender.sendMessage(ChatColor.YELLOW + "/mellac debug" + ChatColor.GRAY + " - Переключить режим отладки");
    }
    
    private void sendStatus(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "=== MellAC Статус ===");
        sender.sendMessage(ChatColor.YELLOW + "Версия: " + ChatColor.WHITE + plugin.getDescription().getVersion());
        sender.sendMessage(ChatColor.YELLOW + "Мониторинг: " + ChatColor.WHITE + 
            (plugin.getConfig().getBoolean("monitoring.enabled") ? 
                ChatColor.GREEN + "Включен" : ChatColor.RED + "Выключен"));
        sender.sendMessage(ChatColor.YELLOW + "Отслеживаемых игроков: " + ChatColor.WHITE + 
            plugin.getCheckManager().getTrackedPlayers());
        sender.sendMessage(ChatColor.YELLOW + "Очередь проверок: " + ChatColor.WHITE + 
            plugin.getCheckManager().getQueueSize());
        sender.sendMessage(ChatColor.YELLOW + "API URL: " + ChatColor.WHITE + 
            plugin.getConfig().getString("api.url"));
        sender.sendMessage(ChatColor.YELLOW + "Отладка: " + ChatColor.WHITE + 
            (plugin.getConfig().getBoolean("debug.enabled") ? 
                ChatColor.GREEN + "Включена" : ChatColor.RED + "Выключена"));
    }
}
