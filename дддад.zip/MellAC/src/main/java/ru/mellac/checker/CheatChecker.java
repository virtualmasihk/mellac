package ru.mellac.checker;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;
import ru.mellac.MellACPlugin;
import ru.mellac.data.PlayerData;

import java.text.DecimalFormat;
import java.util.List;

public class CheatChecker {
    
    private final MellACPlugin plugin;
    private final DecimalFormat df = new DecimalFormat("#.##");
    
    public CheatChecker(MellACPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void checkPlayer(Player player) {
        if (player == null || !player.isOnline()) return;
        
        PlayerData data = plugin.getCheckManager().getPlayerData(player.getUniqueId());
        Location currentLoc = player.getLocation();
        
        // Игнорировать игроков с эффектами если настроено
        if (plugin.getConfig().getBoolean("bypass.ignore-effects", true)) {
            if (player.hasPotionEffect(PotionEffectType.SPEED) ||
                player.hasPotionEffect(PotionEffectType.JUMP) ||
                player.hasPotionEffect(PotionEffectType.LEVITATION) ||
                player.hasPotionEffect(PotionEffectType.SLOW_FALLING)) {
                return;
            }
        }
        
        // Логирование движения
        if (plugin.getConfig().getBoolean("reports.detailed-logs", true)) {
            String log = String.format("Pos: %.2f,%.2f,%.2f | Vel: %.2f,%.2f,%.2f | OnGround: %s",
                currentLoc.getX(), currentLoc.getY(), currentLoc.getZ(),
                player.getVelocity().getX(), player.getVelocity().getY(), player.getVelocity().getZ(),
                player.isOnGround());
            data.addMovementLog(log);
        }
        
        Location lastLoc = data.getLastLocation();
        
        if (lastLoc != null && lastLoc.getWorld().equals(currentLoc.getWorld())) {
            long timeDiff = System.currentTimeMillis() - data.getLastMoveTime();
            
            if (timeDiff > 50) {
                if (plugin.getConfig().getBoolean("detection.speed.enabled", true)) {
                    checkSpeed(player, data, lastLoc, currentLoc, timeDiff);
                }
                
                if (plugin.getConfig().getBoolean("detection.fly.enabled", true)) {
                    checkFly(player, data);
                }
                
                if (plugin.getConfig().getBoolean("detection.teleport.enabled", true)) {
                    checkTeleport(player, data, lastLoc, currentLoc);
                }
                
                if (plugin.getConfig().getBoolean("detection.impossible-actions.enabled", true)) {
                    checkImpossibleActions(player, data, currentLoc);
                }
            }
        }
        
        data.setLastLocation(currentLoc);
    }
    
    private void checkSpeed(Player player, PlayerData data, Location from, Location to, long timeDiff) {
        double distance = from.distance(to);
        double speed = (distance / timeDiff) * 1000.0;
        double maxSpeed = plugin.getConfig().getDouble("detection.speed.max-speed", 12.0);
        
        if (player.isSprinting()) {
            maxSpeed *= 1.3;
        }
        
        if (speed > maxSpeed && !player.isFlying() && !player.isInsideVehicle()) {
            data.addViolation("speed");
            int threshold = plugin.getConfig().getInt("detection.speed.threshold", 3);
            
            if (data.getViolations("speed") >= threshold) {
                reportCheat(player, data, "Speed", 
                    "Скорость: " + df.format(speed) + " б/с (макс: " + df.format(maxSpeed) + ")",
                    "medium");
                data.resetViolations("speed");
            }
            
            if (plugin.getConfig().getBoolean("debug.verbose", false)) {
                plugin.getLogger().info(player.getName() + " превысил скорость: " + df.format(speed) + " б/с");
            }
        }
    }
    
    private void checkFly(Player player, PlayerData data) {
        if (player.isOnGround() || player.isFlying() || player.isGliding() || player.isInsideVehicle()) {
            data.resetAirTime();
            return;
        }
        
        data.incrementAirTime(50);
        long maxAirTime = (long) (plugin.getConfig().getDouble("detection.fly.max-air-time", 3.0) * 1000);
        
        if (data.getAirTime() > maxAirTime) {
            data.addViolation("fly");
            int threshold = plugin.getConfig().getInt("detection.fly.threshold", 2);
            
            if (data.getViolations("fly") >= threshold) {
                reportCheat(player, data, "Fly", 
                    "Время в воздухе: " + (data.getAirTime() / 1000.0) + "с",
                    "high");
                data.resetViolations("fly");
                data.resetAirTime();
            }
        }
    }
    
    private void checkTeleport(Player player, PlayerData data, Location from, Location to) {
        double distance = from.distance(to);
        double maxDistance = plugin.getConfig().getDouble("detection.teleport.max-distance", 10.0);
        
        if (distance > maxDistance && !player.isInsideVehicle()) {
            data.addViolation("teleport");
            int threshold = plugin.getConfig().getInt("detection.teleport.threshold", 2);
            
            if (data.getViolations("teleport") >= threshold) {
                reportCheat(player, data, "Teleport", 
                    "Мгновенное перемещение на " + df.format(distance) + " блоков",
                    "high");
                data.resetViolations("teleport");
            }
        }
    }
    
    private void checkImpossibleActions(Player player, PlayerData data, Location loc) {
        if (!player.isOnGround() && loc.getBlock().getType().isSolid()) {
            data.addViolation("phase");
            int threshold = plugin.getConfig().getInt("detection.impossible-actions.threshold", 1);
            
            if (data.getViolations("phase") >= threshold) {
                reportCheat(player, data, "Phase", 
                    "Движение сквозь блоки",
                    "high");
                data.resetViolations("phase");
            }
        }
    }
    
    // Проверки боя
    public void checkCombat(Player attacker, Player victim, PlayerData data) {
        if (plugin.getConfig().getBoolean("detection.killaura.enabled", true)) {
            checkKillAura(attacker, victim, data);
        }
        
        if (plugin.getConfig().getBoolean("detection.aim.enabled", true)) {
            checkAim(attacker, data);
        }
        
        if (plugin.getConfig().getBoolean("detection.hitbox.enabled", true)) {
            checkHitbox(attacker, victim, data);
        }
    }
    
    private void checkKillAura(Player attacker, Player victim, PlayerData data) {
        List<Long> timings = data.getAttackTimings();
        if (timings.size() >= 5) {
            double avgTiming = timings.stream().mapToLong(Long::longValue).average().orElse(0);
            double minTiming = plugin.getConfig().getDouble("detection.killaura.min-attack-delay", 100.0);
            
            if (avgTiming < minTiming) {
                data.addViolation("killaura_speed");
                int threshold = plugin.getConfig().getInt("detection.killaura.threshold", 3);
                
                if (data.getViolations("killaura_speed") >= threshold) {
                    reportCheat(attacker, data, "KillAura", 
                        "Слишком быстрые атаки: " + df.format(avgTiming) + "мс",
                        "high");
                    data.resetViolations("killaura_speed");
                    notifyAdmins(attacker, "KillAura");
                }
            }
        }
        
        List<Float> yawChanges = data.getRecentYawChanges();
        if (yawChanges.size() >= 3) {
            float yawVariance = calculateVariance(yawChanges);
            float minVariance = (float) plugin.getConfig().getDouble("detection.killaura.min-yaw-variance", 0.5);
            
            if (yawVariance < minVariance) {
                data.addViolation("killaura_rotation");
                int threshold = plugin.getConfig().getInt("detection.killaura.threshold", 3);
                
                if (data.getViolations("killaura_rotation") >= threshold) {
                    reportCheat(attacker, data, "KillAura", 
                        "Атака без поворота головы",
                        "high");
                    data.resetViolations("killaura_rotation");
                    notifyAdmins(attacker, "KillAura");
                }
            }
        }
    }
    
    private void checkAim(Player attacker, PlayerData data) {
        List<Float> yawChanges = data.getRecentYawChanges();
        List<Float> pitchChanges = data.getRecentPitchChanges();
        
        if (yawChanges.size() >= 10 && pitchChanges.size() >= 10) {
            float yawVariance = calculateVariance(yawChanges);
            float pitchVariance = calculateVariance(pitchChanges);
            
            float maxVariance = (float) plugin.getConfig().getDouble("detection.aim.max-variance", 0.3);
            
            if (yawVariance < maxVariance && pitchVariance < maxVariance) {
                data.addViolation("aim_perfect");
                int threshold = plugin.getConfig().getInt("detection.aim.threshold", 5);
                
                if (data.getViolations("aim_perfect") >= threshold) {
                    reportCheat(attacker, data, "Aim", 
                        "Подозрительно точное наведение",
                        "medium");
                    data.resetViolations("aim_perfect");
                    notifyAdmins(attacker, "Aim");
                }
            }
            
            for (int i = 1; i < yawChanges.size(); i++) {
                float yawDiff = Math.abs(yawChanges.get(i) - yawChanges.get(i - 1));
                float maxSnap = (float) plugin.getConfig().getDouble("detection.aim.max-snap-angle", 90.0);
                
                if (yawDiff > maxSnap) {
                    data.addViolation("aim_snap");
                    int threshold = plugin.getConfig().getInt("detection.aim.threshold", 5);
                    
                    if (data.getViolations("aim_snap") >= threshold) {
                        reportCheat(attacker, data, "Aim", 
                            "Резкий поворот на " + df.format(yawDiff) + " градусов",
                            "high");
                        data.resetViolations("aim_snap");
                        notifyAdmins(attacker, "Aim");
                        break;
                    }
                }
            }
        }
    }
    
    private void checkHitbox(Player attacker, Player victim, PlayerData data) {
        double distance = attacker.getLocation().distance(victim.getLocation());
        double maxReach = plugin.getConfig().getDouble("detection.hitbox.max-reach", 3.5);
        
        if (distance > maxReach) {
            data.addViolation("hitbox_reach");
            int threshold = plugin.getConfig().getInt("detection.hitbox.threshold", 3);
            
            if (data.getViolations("hitbox_reach") >= threshold) {
                reportCheat(attacker, data, "Hitbox", 
                    "Атака с расстояния " + df.format(distance) + " блоков",
                    "high");
                data.resetViolations("hitbox_reach");
                notifyAdmins(attacker, "Hitbox");
            }
        }
        
        double angle = getAngleBetween(attacker, victim);
        double maxAngle = plugin.getConfig().getDouble("detection.hitbox.max-angle", 90.0);
        
        if (angle > maxAngle) {
            data.addViolation("hitbox_angle");
            int threshold = plugin.getConfig().getInt("detection.hitbox.threshold", 3);
            
            if (data.getViolations("hitbox_angle") >= threshold) {
                reportCheat(attacker, data, "Hitbox", 
                    "Атака под углом " + df.format(angle) + " градусов",
                    "medium");
                data.resetViolations("hitbox_angle");
                notifyAdmins(attacker, "Hitbox");
            }
        }
    }
    
    private float calculateVariance(List<Float> values) {
        if (values.isEmpty()) return 0;
        
        float mean = 0;
        for (float v : values) {
            mean += v;
        }
        mean /= values.size();
        
        float variance = 0;
        for (float v : values) {
            variance += Math.pow(v - mean, 2);
        }
        return variance / values.size();
    }
    
    private double getAngleBetween(Player attacker, Player victim) {
        org.bukkit.util.Vector attackerDir = attacker.getLocation().getDirection();
        org.bukkit.util.Vector toVictim = victim.getLocation().toVector()
            .subtract(attacker.getLocation().toVector()).normalize();
        
        double dot = attackerDir.dot(toVictim);
        return Math.toDegrees(Math.acos(dot));
    }
    
    private void notifyAdmins(Player player, String cheatType) {
        if (!plugin.getConfig().getBoolean("notifications.enabled", true)) return;
        
        String message = plugin.getConfig().getString("notifications.message", 
            "&e[MellAC] &fВозможный читер: &c{player} &f- &6{cheat} &f- Проверьте на сайте!")
            .replace("{player}", player.getName())
            .replace("{cheat}", cheatType)
            .replace("&", "§");
        
        for (Player admin : plugin.getServer().getOnlinePlayers()) {
            if (admin.hasPermission("mellac.notify")) {
                admin.sendMessage(message);
            }
        }
        
        plugin.getLogger().warning("Обнаружен возможный читер: " + player.getName() + " - " + cheatType);
    }
    
    private void reportCheat(Player player, PlayerData data, String cheatType, String reason, String severity) {
        String minSeverity = plugin.getConfig().getString("reports.min-severity", "medium");
        if (!shouldReport(severity, minSeverity)) {
            return;
        }
        
        String playerIp = player.getAddress() != null ? 
            player.getAddress().getAddress().getHostAddress() : null;
        
        if (plugin.getConfig().getBoolean("reports.detailed-logs", true)) {
            StringBuilder detailedReason = new StringBuilder(reason);
            detailedReason.append(" | Движения: ");
            for (String log : data.getMovementLog()) {
                detailedReason.append(log).append("; ");
            }
            reason = detailedReason.toString();
        }
        
        plugin.getApiClient().sendCheatReport(
            player.getName(),
            playerIp,
            cheatType,
            reason,
            severity
        );
        
        data.clearMovementLog();
        
        if (plugin.getConfig().getBoolean("debug.enabled", false)) {
            plugin.getLogger().info("Отчёт: " + player.getName() + " - " + cheatType + " (" + severity + ")");
        }
    }
    
    private boolean shouldReport(String severity, String minSeverity) {
        int severityLevel = getSeverityLevel(severity);
        int minLevel = getSeverityLevel(minSeverity);
        return severityLevel >= minLevel;
    }
    
    private int getSeverityLevel(String severity) {
        switch (severity.toLowerCase()) {
            case "low": return 1;
            case "medium": return 2;
            case "high": return 3;
            default: return 2;
        }
    }
}
