package ru.mellac.data;

import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.*;

public class PlayerData {
    
    private final UUID uuid;
    private Location lastLocation;
    private long lastMoveTime;
    private long airTime;
    private final List<Location> recentLocations;
    private final Map<String, Integer> violations;
    private final List<String> movementLog;
    
    // Данные для проверки боя
    private Player lastAttackedEntity;
    private long lastAttackTime;
    private final List<Float> recentYawChanges;
    private final List<Float> recentPitchChanges;
    private int consecutiveHeadshots;
    private final List<Long> attackTimings;
    
    public PlayerData(UUID uuid) {
        this.uuid = uuid;
        this.recentLocations = new ArrayList<>();
        this.violations = new HashMap<>();
        this.movementLog = new ArrayList<>();
        this.airTime = 0;
        this.lastMoveTime = System.currentTimeMillis();
        this.recentYawChanges = new ArrayList<>();
        this.recentPitchChanges = new ArrayList<>();
        this.consecutiveHeadshots = 0;
        this.attackTimings = new ArrayList<>();
    }
    
    public UUID getUuid() {
        return uuid;
    }
    
    public Location getLastLocation() {
        return lastLocation;
    }
    
    public void setLastLocation(Location location) {
        this.lastLocation = location;
        this.lastMoveTime = System.currentTimeMillis();
        
        // Сохранить последние 10 позиций
        recentLocations.add(location.clone());
        if (recentLocations.size() > 10) {
            recentLocations.remove(0);
        }
    }
    
    public long getLastMoveTime() {
        return lastMoveTime;
    }
    
    public long getAirTime() {
        return airTime;
    }
    
    public void setAirTime(long airTime) {
        this.airTime = airTime;
    }
    
    public void incrementAirTime(long delta) {
        this.airTime += delta;
    }
    
    public void resetAirTime() {
        this.airTime = 0;
    }
    
    public List<Location> getRecentLocations() {
        return new ArrayList<>(recentLocations);
    }
    
    public void addViolation(String type) {
        violations.put(type, violations.getOrDefault(type, 0) + 1);
    }
    
    public int getViolations(String type) {
        return violations.getOrDefault(type, 0);
    }
    
    public void resetViolations(String type) {
        violations.put(type, 0);
    }
    
    public void addMovementLog(String log) {
        movementLog.add(log);
        // Хранить только последние 20 записей
        if (movementLog.size() > 20) {
            movementLog.remove(0);
        }
    }
    
    public List<String> getMovementLog() {
        return new ArrayList<>(movementLog);
    }
    
    public void clearMovementLog() {
        movementLog.clear();
    }
    
    // Combat data methods
    public Player getLastAttackedEntity() {
        return lastAttackedEntity;
    }
    
    public void setLastAttackedEntity(Player entity) {
        this.lastAttackedEntity = entity;
    }
    
    public long getLastAttackTime() {
        return lastAttackTime;
    }
    
    public void setLastAttackTime(long time) {
        this.lastAttackTime = time;
    }
    
    public void addYawChange(float yaw) {
        recentYawChanges.add(yaw);
        if (recentYawChanges.size() > 20) {
            recentYawChanges.remove(0);
        }
    }
    
    public void addPitchChange(float pitch) {
        recentPitchChanges.add(pitch);
        if (recentPitchChanges.size() > 20) {
            recentPitchChanges.remove(0);
        }
    }
    
    public List<Float> getRecentYawChanges() {
        return new ArrayList<>(recentYawChanges);
    }
    
    public List<Float> getRecentPitchChanges() {
        return new ArrayList<>(recentPitchChanges);
    }
    
    public int getConsecutiveHeadshots() {
        return consecutiveHeadshots;
    }
    
    public void incrementHeadshots() {
        this.consecutiveHeadshots++;
    }
    
    public void resetHeadshots() {
        this.consecutiveHeadshots = 0;
    }
    
    public void addAttackTiming(long timing) {
        attackTimings.add(timing);
        if (attackTimings.size() > 10) {
            attackTimings.remove(0);
        }
    }
    
    public List<Long> getAttackTimings() {
        return new ArrayList<>(attackTimings);
    }
}
