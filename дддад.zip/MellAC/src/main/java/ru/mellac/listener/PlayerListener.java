package ru.mellac.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import ru.mellac.MellACPlugin;

public class PlayerListener implements Listener {
    
    private final MellACPlugin plugin;
    
    public PlayerListener(MellACPlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        // Инициализация данных игрока
        plugin.getCheckManager().getPlayerData(event.getPlayer().getUniqueId());
        
        if (plugin.getConfig().getBoolean("debug.enabled", false)) {
            plugin.getLogger().info("Начат мониторинг игрока: " + event.getPlayer().getName());
        }
    }
    
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        // Очистка данных игрока
        plugin.getCheckManager().removePlayerData(event.getPlayer().getUniqueId());
        
        if (plugin.getConfig().getBoolean("debug.enabled", false)) {
            plugin.getLogger().info("Остановлен мониторинг игрока: " + event.getPlayer().getName());
        }
    }
}
