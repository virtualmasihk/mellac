package ru.mellac.listener;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import ru.mellac.MellACPlugin;
import ru.mellac.data.PlayerData;

public class CombatListener implements Listener {
    
    private final MellACPlugin plugin;
    
    public CombatListener(MellACPlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player)) return;
        if (!(event.getEntity() instanceof Player)) return;
        
        Player attacker = (Player) event.getDamager();
        Player victim = (Player) event.getEntity();
        
        // Игнорировать bypass игроков
        if (attacker.hasPermission("mellac.bypass")) return;
        
        PlayerData data = plugin.getCheckManager().getPlayerData(attacker.getUniqueId());
        
        // Сохранить данные атаки
        long currentTime = System.currentTimeMillis();
        long timeSinceLastAttack = currentTime - data.getLastAttackTime();
        
        data.setLastAttackedEntity(victim);
        data.setLastAttackTime(currentTime);
        data.addAttackTiming(timeSinceLastAttack);
        
        // Сохранить изменения взгляда
        float yaw = attacker.getLocation().getYaw();
        float pitch = attacker.getLocation().getPitch();
        data.addYawChange(yaw);
        data.addPitchChange(pitch);
        
        // Проверить на читы
        plugin.getCheatChecker().checkCombat(attacker, victim, data);
    }
}
