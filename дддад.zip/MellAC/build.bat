@echo off
echo ========================================
echo MellAC Plugin Builder
echo ========================================
echo.

REM Установка Maven в PATH
set MAVEN_HOME=C:\Users\holac\Desktop\apache-maven-3.9.12
set PATH=%MAVEN_HOME%\bin;%PATH%

echo Проверка Maven...
call mvn -version
if errorlevel 1 (
    echo ОШИБКА: Maven не найден!
    echo Убедитесь что Maven установлен в: %MAVEN_HOME%
    pause
    exit /b 1
)

echo.
echo Начинаем сборку плагина...
echo.

call mvn clean package

if errorlevel 1 (
    echo.
    echo ОШИБКА: Сборка не удалась!
    pause
    exit /b 1
)

echo.
echo ========================================
echo Сборка завершена успешно!
echo ========================================
echo.
echo Плагин находится в: target\MellAC-1.0.0.jar
echo.
echo Скопируйте его в папку plugins вашего сервера
echo.
pause
